# filepath: /Users/alexanderkasten/Downloads/plugin.video.xstream/sites/burningseries.py
# -*- coding: utf-8 -*-
# Python 3

from resources.lib.handler.ParameterHandler import ParameterHandler
from resources.lib.handler.requestHandler import cRequestHandler
from resources.lib.tools import logger, cParser
from resources.lib.gui.guiElement import cGuiElement
from resources.lib.config import cConfig
from resources.lib.gui.gui import cGui

SITE_IDENTIFIER = 'burningseries'
SITE_NAME = 'Burning Series'
SITE_ICON = 'burningseries.png'

DOMAIN = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '.domain')
STATUS = cConfig().getSetting('plugin_' + SITE_IDENTIFIER + '_status')
ACTIVE = cConfig().getSetting('plugin_' + SITE_IDENTIFIER)

if DOMAIN == '186.2.175.5':
    URL_MAIN = 'http://' + DOMAIN
    REFERER = 'http://' + DOMAIN
else:
    URL_MAIN = 'https://' + DOMAIN
    REFERER = 'https://' + DOMAIN

URL_SERIES = URL_MAIN + '/andere-serien'
URL_NEW_SERIES = URL_MAIN + '/neu'
URL_NEW_EPISODES = URL_MAIN + '/neue-episoden'
URL_POPULAR = URL_MAIN + '/beliebte-serien'


def load():
    logger.info('Load %s' % SITE_NAME)
    params = ParameterHandler()
    params.setParam('sUrl', URL_SERIES)
    cGui().addFolder(cGuiElement('Alle Serien', SITE_IDENTIFIER, 'showAllSeries'), params)
    params.setParam('sUrl', URL_NEW_SERIES)
    cGui().addFolder(cGuiElement('Neue Serien', SITE_IDENTIFIER, 'showEntries'), params)
    params.setParam('sUrl', URL_NEW_EPISODES)
    cGui().addFolder(cGuiElement('Neue Episoden', SITE_IDENTIFIER, 'showNewEpisodes'), params)
    params.setParam('sUrl', URL_POPULAR)
    cGui().addFolder(cGuiElement('Beliebte Serien', SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showValue():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(sUrl)
    oRequest.cacheTime = 60 * 60 * 24
    sHtmlContent = oRequest.request()
    isMatch, sContainer = cParser.parseSingleResult(sHtmlContent, '<ul[^>]*class="%s"[^>]*>(.*?)<\\/ul>' % params.getValue('sCont'))
    if isMatch:
        isMatch, aResult = cParser.parse(sContainer, '<li>\\s*<a[^>]*href="([^"]*)"[^>]*>(.*?)<\\/a>\\s*<\\/li>')
    if not isMatch:
        cGui().showInfo()
        return

    for sUrl, sName in aResult:
        sUrl = sUrl if sUrl.startswith('http') else URL_MAIN + sUrl
        params.setParam('sUrl', sUrl)
        cGui().addFolder(cGuiElement(sName, SITE_IDENTIFIER, 'showEntries'), params)
    cGui().setEndOfDirectory()


def showAllSeries(entryUrl=False, sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    oRequest.cacheTime = 60 * 60 * 24
    sHtmlContent = oRequest.request()
    pattern = '<a[^>]*href="(/serie/[^"]*)"[^>]*title="([^"]*)"' 
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui:
            oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName in aResult:
        if sSearchText and not cParser().search(sSearchText, sName):
            continue
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setMediaType('tvshow')
        params.setParam('sUrl', URL_MAIN + sUrl)
        params.setParam('TVShowTitle', sName)
        oGui.addFolder(oGuiElement, params, True, total)
    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showNewEpisodes(entryUrl=False, sGui=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    sHtmlContent = oRequest.request()
    pattern = '<div[^>]*class="col-md-[^"]*"[^>]*>\\s*<a[^>]*href="([^"]*)"[^>]*>\\s*<strong>([^<]+)</strong>\\s*<span[^>]*>([^<]+)</span>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui:
            oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sName, sInfo in aResult:
        sMovieTitle = sName + ' ' + sInfo
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setMediaType('tvshow')
        oGuiElement.setTitle(sMovieTitle)
        params.setParam('sUrl', URL_MAIN + sUrl)
        params.setParam('TVShowTitle', sMovieTitle)
        oGui.addFolder(oGuiElement, params, True, total)
    if not sGui:
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showEntries(entryUrl=False, sGui=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    if not entryUrl:
        entryUrl = params.getValue('sUrl')
    oRequest = cRequestHandler(entryUrl, ignoreErrors=(sGui is not False))
    oRequest.cacheTime = 60 * 60 * 6
    sHtmlContent = oRequest.request()
    pattern = '<div[^>]*class="col-md-[^"]*"[^>]*>.*?<a[^>]*href="([^"]*)"[^>]*>.*?data-src="([^"]*).*?<h3>(.*?)<span[^>]*class="paragraph-end">.*?</div>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        if not sGui:
            oGui.showInfo()
        return

    total = len(aResult)
    for sUrl, sThumbnail, sName in aResult:
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showSeasons')
        oGuiElement.setThumbnail(URL_MAIN + sThumbnail)
        oGuiElement.setMediaType('tvshow')
        params.setParam('sUrl', URL_MAIN + sUrl)
        params.setParam('TVShowTitle', sName)
        oGui.addFolder(oGuiElement, params, True, total)
    if not sGui:
        pattern = 'pagination">.*?<a href="([^"]+)">&gt;</a>.*?</a></div>'
        isMatchNextPage, sNextUrl = cParser.parseSingleResult(sHtmlContent, pattern)
        if isMatchNextPage:
            params.setParam('sUrl', sNextUrl)
            oGui.addNextPage(SITE_IDENTIFIER, 'showEntries', params)
        oGui.setView('tvshows')
        oGui.setEndOfDirectory()


def showSeasons():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sTVShowTitle = params.getValue('TVShowTitle')
    oRequest = cRequestHandler(sUrl)
    sHtmlContent = oRequest.request()
    pattern = '<a[^>]*href="([^"]*)"[^>]*>(Staffel [0-9]+)</a>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '<p[^>]*data-full-description="(.*?)"[^>]*>')
    isThumbnail, sThumbnail = cParser.parseSingleResult(sHtmlContent, '<img[^>]*class="cover"[^>]*src="([^"]+)"')
    if isThumbnail and sThumbnail.startswith('/'):
        sThumbnail = URL_MAIN + sThumbnail
    total = len(aResult)
    for sUrl, sName in aResult:
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showEpisodes')
        oGuiElement.setMediaType('season')
        if isThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        oGuiElement.setTVShowTitle(sTVShowTitle)
        oGuiElement.setSeason(sName)
        params.setParam('sUrl', URL_MAIN + sUrl)
        params.setParam('sSeason', sName)
        params.setParam('sThumbnail', sThumbnail)
        cGui().addFolder(oGuiElement, params, True, total)
    cGui().setView('seasons')
    cGui().setEndOfDirectory()


def showEpisodes():
    params = ParameterHandler()
    sUrl = params.getValue('sUrl')
    sTVShowTitle = params.getValue('TVShowTitle')
    sSeason = params.getValue('sSeason')
    sThumbnail = params.getValue('sThumbnail')
    oRequest = cRequestHandler(sUrl)
    oRequest.cacheTime = 60 * 60 * 4
    sHtmlContent = oRequest.request()
    pattern = '<tr>.*?<a href="([^"]*)" title="([^"]*)">([0-9]+)</a>'
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    isDesc, sDesc = cParser.parseSingleResult(sHtmlContent, '<p[^>]*data-full-description="(.*?)"[^>]*>')
    total = len(aResult)
    for sUrl, sTitle, sEpNum in aResult:
        sName = '%s - %s' % (sEpNum, sTitle)
        oGuiElement = cGuiElement(sName, SITE_IDENTIFIER, 'showHosters')
        oGuiElement.setMediaType('episode')
        oGuiElement.setSeason(sSeason)
        oGuiElement.setEpisode(int(sEpNum))
        oGuiElement.setTVShowTitle(sTVShowTitle)
        if sThumbnail:
            oGuiElement.setThumbnail(sThumbnail)
        if isDesc:
            oGuiElement.setDescription(sDesc)
        params.setParam('sUrl', URL_MAIN + sUrl)
        params.setParam('entryUrl', sUrl)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('episodes')
    cGui().setEndOfDirectory()


def showHosters():
    sUrl = ParameterHandler().getValue('sUrl')
    sHtmlContent = cRequestHandler(sUrl, caching=False).request()
    pattern = '<td class="hosterSite">.*?<a href="([^"]*)" title="([^"]*)"' 
    isMatch, aResult = cParser.parse(sHtmlContent, pattern)
    if not isMatch:
        cGui().showInfo()
        return

    total = len(aResult)
    for sHosterUrl, sHosterName in aResult:
        oGuiElement = cGuiElement(sHosterName, SITE_IDENTIFIER, 'getHosterUrl')
        oGuiElement.setMediaType('stream')
        oGuiElement.setTitle(sHosterName)
        params = ParameterHandler()
        params.setParam('sHosterUrl', sHosterUrl)
        params.setParam('sHosterName', sHosterName)
        cGui().addFolder(oGuiElement, params, False, total)
    cGui().setView('streams')
    cGui().setEndOfDirectory()


def getHosterUrl():
    params = ParameterHandler()
    sHosterUrl = params.getValue('sHosterUrl')
    sHosterName = params.getValue('sHosterName')
    oGuiElement = cGuiElement(sHosterName, SITE_IDENTIFIER, None)
    oGuiElement.setMediaType('video')
    oGuiElement.setUrl(sHosterUrl)
    cGui().addLink(oGuiElement)
    cGui().setEndOfDirectory()


def showSearch():
    sSearchText = cGui().showKeyBoard(sHeading='Suche')
    if not sSearchText:
        return
    _search(False, sSearchText)
    cGui().setEndOfDirectory()


def _search(oGui, sSearchText):
    SSsearch(oGui, sSearchText)


def SSsearch(sGui=False, sSearchText=False):
    oGui = sGui if sGui else cGui()
    params = ParameterHandler()
    params.getValue('sSearchText')
    oRequest = cRequestHandler(URL_SERIES, caching=True, ignoreErrors=(sGui is not False))
    oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequest.addHeaderEntry('Referer', REFERER + '/serien')
    oRequest.addHeaderEntry('Origin', REFERER)
    oRequest.addHeaderEntry('Content-Type', 'application/x-www-form-urlencoded; charset=UTF-8')
    oRequest.addHeaderEntry('Upgrade-Insecure-Requests', '1')
    oRequest.cacheTime = 60 * 60 * 24
    sHtmlContent = oRequest.request()
    if not sHtmlContent:
        return

    sst = sSearchText.lower()
    pattern = '<li><a data.+?href="([^"]+)".+?">(.*?)\\<\\/a><\\/l'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, pattern)
    if not aResult[0]:
        oGui.showInfo()
        return

    total = len(aResult[1])
    for link, title in aResult[1]:
        if not sst in title.lower():
            continue
        try:
            sThumbnail, sDescription = getMetaInfo(link, title)
            oGuiElement = cGuiElement(title, SITE_IDENTIFIER, 'showSeasons')
            if sThumbnail:
                oGuiElement.setThumbnail(URL_MAIN + sThumbnail)
            if sDescription:
                oGuiElement.setDescription(sDescription)
            oGuiElement.setTVShowTitle(title)
            oGuiElement.setMediaType('tvshow')
            params.setParam('sUrl', URL_MAIN + link)
            params.setParam('sName', title)
            oGui.addFolder(oGuiElement, params, True, total)
        except Exception:
            oGuiElement = cGuiElement(title, SITE_IDENTIFIER, 'showSeasons')
            oGuiElement.setTVShowTitle(title)
            oGuiElement.setMediaType('tvshow')
            params.setParam('sUrl', URL_MAIN + link)
            params.setParam('sName', title)
            oGui.addFolder(oGuiElement, params, True, total)
    if not sGui:
        oGui.setView('tvshows')


def getMetaInfo(link, title):
    oGui = cGui()
    oRequest = cRequestHandler(URL_MAIN + link, caching=False)
    oRequest.addHeaderEntry('X-Requested-With', 'XMLHttpRequest')
    oRequest.addHeaderEntry('Referer', REFERER + '/serien')
    oRequest.addHeaderEntry('Origin', REFERER)
    sHtmlContent = oRequest.request()
    if not sHtmlContent:
        return None, None
    pattern = 'seriesCoverBox">.*?data-src="([^"]+).*?data-full-description="([^"]+)"'
    oParser = cParser()
    aResult = oParser.parse(sHtmlContent, pattern)
    if not aResult[0]:
        return None, None
    for sImg, sDescr in aResult[1]:
        return sImg, sDescr
