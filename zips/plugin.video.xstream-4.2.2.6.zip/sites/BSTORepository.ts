import fetch from 'node-fetch';
import cheerio from 'cheerio';

import { Episode, IRepository, Season, Serie } from './IRepository';
import getConfig from '../../../util/getConfig';
import { Logger } from '../../../util/Logger';
const { SocksProxyAgent } = require('socks-proxy-agent');

const logger = new Logger('BSTORepository');
const config = getConfig();
const socksproxy = `socks5://${config.socksproxy.username}:${config.socksproxy.password}@${config.socksproxy.host}:${config.socksproxy.port}`;
const agent = config.useProxy ? new SocksProxyAgent(socksproxy) : undefined;

const ROOT_URI = 'https://bs.to';

export default class BSTORepository implements IRepository {
  private clearCacheTimer: NodeJS.Timeout | null = null;
  private allSeries: Serie[] = [];

  async initialize(): Promise<void> {
    this.allSeries = await this.getAllSeries();
    this.clearCacheTimer = setInterval(() => {
      this.allSeries = [];
      // 2 hours
      // }, 7200000);
    }, 86400000); // 24 hours
  }

  clearCache(): void {
    this.allSeries = [];
  }

  async getAllSeries(): Promise<Serie[]> {
    if (this.allSeries.length !== 0) {
      logger.info('Returning cached series list');
      return this.allSeries;
    }

    logger.info('Fetching all series from bs.to');
    const result = await fetch(ROOT_URI + '/andere-serien', {
      method: 'get',
      headers: {
        'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
      },
      agent: agent,
    });

    const htmlResult = await result.text();
    const $ = cheerio.load(htmlResult);

    const series = $('#seriesContainer a')
      .map((index, element) => {
        return {
          id: index + 1,
          link: element.attribs.href,
          name: element.attribs.title,
          repository: 'bs.to',
        };
      })
      .toArray();

    this.allSeries = series;
    logger.info(`Fetched ${series.length} series`);

    return series;
  }

  async getSeasonsByName(seriesName: string): Promise<Season[]> {
    if (this.allSeries.length === 0) {
      logger.info('Series cache is empty, fetching all series');
      await this.getAllSeries();
    }

    logger.info(`Fetching seasons for series: ${seriesName}`);
    const serie =
      this.allSeries.find((serie) => serie.link.toLowerCase() === `serie/${seriesName.toLowerCase()}`) ??
      this.allSeries.find((serie) => serie.link.toLowerCase().includes(seriesName.toLowerCase()));

    if (serie == null) {
      const errorMessage = `Serie with name \`${seriesName}\` could not be found!`;
      logger.error(errorMessage);
      throw new Error(errorMessage);
    }

    const result = await fetch(ROOT_URI + '/' + serie.link, {
      method: 'get',
      headers: {
        'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
      },
      agent,
    });

    const htmlResult = await result.text();
    const $ = cheerio.load(htmlResult);

    const languages = $('.series-language option')
      .map((index, element) => {
        return {
          language: element.attribs.value,
          defaultSelected: element.attribs.selected != null,
        };
      })
      .toArray();

    const defaultLanguage = languages.find((element) => element.defaultSelected);

    const coverLink = $('#sp_right > img').attr('src');
    const description = $('#sp_left > p').text();
    const seasons = $('#seasons a')
      .map((index, element) => {
        return {
          id: index + 1,
          link: element.attribs.href,
          name: $(element).text(),
          language: defaultLanguage,
          cover: coverLink,
          description: description,
          repository: 'bs.to',
          seriesName: serie.name,
        };
      })
      .toArray();

    const allSeasons = [...seasons];

    const languagesWithoutDefault = languages.filter((language) => !language.defaultSelected);

    languagesWithoutDefault.forEach((language) => {
      const deepCopy = JSON.parse(JSON.stringify(seasons)) as Season[];

      const mappedSeasons = deepCopy.map((season) => {
        season.link = season.link.replace(`/${defaultLanguage.language}`, `/${language.language}`);
        season.language = language;
        return season;
      });

      allSeasons.push(...mappedSeasons);
    });

    logger.info(`Fetched ${allSeasons.length} seasons for series: ${seriesName}`);
    return allSeasons;
  }

  async getEpisodesForSerieBySeason(seriesName: string, seasonNumber: string): Promise<Episode[]> {
    if (this.allSeries.length === 0) {
      logger.info('Series cache is empty, fetching all series');
      await this.getAllSeries();
    }

    logger.info(`Fetching episodes for series: ${seriesName}, season: ${seasonNumber}`);
    const serie =
      this.allSeries.find((serie) => serie.link.toLowerCase() === `serie/${seriesName.toLowerCase()}`) ??
      this.allSeries.find((serie) => serie.link.toLowerCase().includes(seriesName.toLowerCase()));

    if (serie == null) {
      const errorMessage = `Serie with name \`${seriesName}\` could not be found!`;
      logger.error(errorMessage);
      throw new Error(errorMessage);
    }

    const result = await fetch(ROOT_URI + '/' + serie.link + `/${seasonNumber}`, {
      method: 'get',
      headers: {
        'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
      },
      agent,
    });

    const htmlResult = await result.text();
    const $ = cheerio.load(htmlResult);

    const languages = $('.series-language option')
      .map((index, element) => {
        return {
          language: element.attribs.value,
          defaultSelected: element.attribs.selected != null,
        };
      })
      .toArray();

    const defaultLanguage = languages.find((element) => element.defaultSelected);

    if (defaultLanguage == null) {
      logger.warn(`No default language found for series: ${seriesName}, season: ${seasonNumber}`);
      return [];
    }

    const getEpisodes = (htmlResult: string, language: string) => {
      const $ = cheerio.load(htmlResult);

      const episodes = $('.episodes tr')
        .map((index, element) => {
          const episodeInfos = $(element).children('td:nth-child(1)').children();

          const episodeHosters = $(element)
            .children('td:nth-child(3)')
            .children()
            .map((index, element) => {
              return {
                link: element.attribs.href,
                name: element.attribs.title,
                repository: 'bs.to',
              };
            })
            .toArray();

          return {
            id: index + 1,
            link: episodeInfos.attr('href'),
            name: episodeInfos.attr('title'),
            language: language,
            episodeNumber: parseInt($(episodeInfos).text()),
            seasonNumber: parseInt(seasonNumber),
            links: episodeHosters,
            repository: 'bs.to',
            seriesName: serie.name,
          };
        })
        .toArray();

      return episodes;
    };

    const episodes = getEpisodes(htmlResult, defaultLanguage.language);

    const allEpisodes = [...episodes];

    const languagesWithoutDefault = languages.filter((language) => !language.defaultSelected);

    for (const language of languagesWithoutDefault) {
      const result = await fetch(ROOT_URI + '/' + serie.link + `/${seasonNumber}` + `/${language.language}`, {
        method: 'get',
        headers: {
          'Accept-Language': 'de-DE,de;q=0.9,en-US;q=0.8,en;q=0.7',
        },
        agent,
      });

      const htmlResult = await result.text();
      const episodes = getEpisodes(htmlResult, language.language);

      allEpisodes.push(...episodes);
    }

    logger.info(`Fetched ${allEpisodes.length} episodes for series: ${seriesName}, season: ${seasonNumber}`);
    return allEpisodes;
  }
}
